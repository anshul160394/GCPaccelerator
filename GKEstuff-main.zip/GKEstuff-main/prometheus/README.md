<h1>Prerequisite</h1> 
1. cert-manager<br/>
2. ingress-nginx<br/>

<h1>Installation steps</h1>
git clone https://gitlab.com/satishbansode/k8sapps.git
<br/>
cd k8sapps/prometheus
<br/>
./setup.sh
