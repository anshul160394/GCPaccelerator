#!/bin/bash

export KUBECONFIG="$(pwd)/gateway-kubeconfig" && \
    gcloud container clusters get-credentials autopilot-cluster-1 --region us-central1 --project yash-innovation
    
kubectl get ns | grep -i 'ingress-nginx' &> /dev/null
if [ $? == 0 ]; then
   echo "Ingress Controller already installed"
else
   echo "Ingress Controller is not installed. Installing Ingress Controller now!"
   #Install ArgoCD
   kubectl apply -f nginx-ingress-controller.yaml
fi
