﻿namespace Result.Models
{
    public class ResultsModel
    {
        public int OptionA { get; set; }

        public int OptionB { get; set; }

        public int VoteCount { get; set; }
    }
}
