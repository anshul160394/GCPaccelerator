#!/bin/bash
kubectl apply -f voting-app/votingApp-main/sample.yaml
