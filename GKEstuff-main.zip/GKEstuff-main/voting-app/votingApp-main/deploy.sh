#!/bin/bash
kubectl apply -f voting-app/votingApp-main/k8s-specifications/
