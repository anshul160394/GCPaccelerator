#!/bin/sh

kubectl apply -f Monitoring_grafana/grafana.yaml
