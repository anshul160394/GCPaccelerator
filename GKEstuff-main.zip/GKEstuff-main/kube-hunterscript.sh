#!/bin/bash
kubectl apply -f job.yaml


# To check the output
# kubectl logs <Name of the Pod>
