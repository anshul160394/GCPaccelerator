#!/bin/bash
apt-get update -y
apt-get install ufw -y
systemctl enable ufw
systemctl start ufw
